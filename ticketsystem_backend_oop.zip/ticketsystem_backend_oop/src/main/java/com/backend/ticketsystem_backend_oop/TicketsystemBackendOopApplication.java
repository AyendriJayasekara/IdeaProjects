package com.backend.ticketsystem_backend_oop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketsystemBackendOopApplication {

    public static void main(String[] args) {
        SpringApplication.run(TicketsystemBackendOopApplication.class, args);
    }

}
